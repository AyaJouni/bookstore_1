const express = require('express')
const router = express.Router();
const mysql = require('mysql')

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'bookstore',
    password:'AyaJouni@05012004',
    
});

// to post the data from server on frontend
router.get("/" , async (req,res) => {
    await con.query(`SELECT * FROM book_copy`,function(err,result,fields) {
        if(err){
            console.log(err)
        }else{
            res.send(result)
        }
    })
})


// is used to get the data from frontend and post it in server
router.post("/",(req,res) => {
    const bookCopyId = req.body.bookCopyId;
    const isbn = req.body.isbn;
    const price = req.body.price;
    const numOfCopies = req.body.numOfCopies;
    const bookId = req.body.bookId;
    const publisherId = req.body.publisherId;
    const publicationyear  = req.body.publicationyear ;
    
    con.query('insert into book_copy values(?,?,?,?,?,?,?)',[bookCopyId,isbn,price,numOfCopies,bookId,publisherId,publicationyear],(err,result) => {
        if(err){
            console.log(err)
        }else{
            res.send("POSTED")
        }
    })
})

module.exports = router;