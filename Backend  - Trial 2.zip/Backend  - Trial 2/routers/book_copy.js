const express = require('express')
const router = express.Router();
const mysql = require('mysql')
router.use(express.json())

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'bookstore',
    password:'AyaJouni@05012004',
    
});

con.connect((err) => {
    if(err){
        console.log(err);
    }else{
        console.log('connected')
    }
})

// to post the data from server on frontend
router.get("/" , async (req,res) => {
    await con.query(`SELECT * FROM book_copy`,function(err,result,fields) {
        if(err){
            console.log(err)
        }else{
            res.send(result)
        }
    })
})


// is used to get the data from frontend and post it in server
router.post("/", async (req,res) => {
    const bookCopyId = req.body.bookCopyId;
    const isbn = req.body.isbn;
    const price = req.body.price;
    const numOfCopies = req.body.numOfCopies;
    const bookId = req.body.bookId;
    const publisherId = req.body.publisherId;
    const publicationYear  = req.body.publicationYear ;

    
    await con.query('insert into book_copy values(?,?,?,?,?,?,?)',[bookCopyId,isbn,price,numOfCopies,bookId,publisherId,publicationYear],(err,result) => {

        if(err){
            console.log(err)
        }else{
            res.send("POSTED")
        }
    })
})

//get the data from server from backend to frontend by id 
router.get("/bookCopy/:bookCopyId", async (req,res) => {
    const bookId = req.params.bookCopyId;
    await con.query("SELECT * FROM book_copy WHERE bookCopyId=?",bookId,(err,result) => {
        if(err){
            console.log(err);
        }else{
            if(result.length==0){
                console.log("id is not present")
            }else{
                res.json(result);
                console.log(value[0].bookCopyId);
                console.log(value[0].isbn);
                console.log(value[0].price);
                console.log(value[0].numOfCopies);
                console.log(value[0].bookId);
                console.log(value[0].publisherId);
                console.log(value[0].publicationYear);
        }
    }
    })
})

//update the values in server 
router.put("/bookCopy/:bookCopyId", async(req,res) => {
    const upid = req.params.bookCopyId;
    const isbn = req.body.isbn;
    const price = req.body.price;
    const numOfCopies = req.body.numOfCopies;
    const bookId = req.body.bookId;
    const publisherId = req.body.publisherId;
    const publicationyear  = req.body.publicationYear ;

    await con.query(`UPDATE book_copy SET isbn=?, price=? ,bookId=?,publisherId=?,publicationyear=? WHERE bookCopyId=? AND numOfCopies=numOfCopies+1`,[isbn,price,numOfCopies,bookId,publisherId,publicationyear,upid])
    if(err){
        console.log(err);
    }else{
        res.send("UPDATED")
    }
})

// is used to delete data from server 
router.delete('/deletedata/:bookCopyId', async (req,res) => {
    const delId = req.params.bookCopyId;
    await con.query(`delete from book_copy where bookCopyId=?`,delId,(err) =>{
        if(err){
            console.log(err);
        }else{
            res.send("DELETED");
        }
    })
})


module.exports = router;