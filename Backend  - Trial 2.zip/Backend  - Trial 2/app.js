const express = require('express')
const app = express ()
const bodyParser =  require('body-parser')
const morgan = require('morgan');
const mysql = require('mysql');
const cors = require('cors');

app.use(cors());
app.options('*',cors())


// middleware to get it as a data from frontend
app.use(bodyParser.json());
app.use(morgan('tiny'))

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'bookstore',
    password:'AyaJouni@05012004',
    
});

con.connect((err) => {
    if(err){
        console.log(err);
    }else{
        console.log('connected')
    }
})

//Routes
const bookCopiesRouter = require('./routers/book_copy');
//const categoriesRouter = require('./routers/categories');
//const usersRouter = require('./routers/users');
//const ordersRouter = require('./routers/orders');



//Routees
app.use('/bookCopiesRouter',bookCopiesRouter)
//app.use('/categories',categoriesRoutes)
//app.use('/bookCopies',ordersRoutes)
//app.use('/categories',usersRoutes)






app.listen(3000, () => {
    console.log('server is running http://localhost:3000')
})